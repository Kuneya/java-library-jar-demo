package mx.uam.azc;



import mx.uam.azc.OperacionArreglo;
import mx.uam.azc.OperacionCadena;
import mx.uam.azc.OperacionSimple;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alumno34
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

      OperacionCadena opC= new OperacionCadena();
      OperacionArreglo opA= new OperacionArreglo();
      OperacionSimple opS= new OperacionSimple();
      
        System.out.println("Operaciones con Arreglos");
      int arreglo[]= {3,5,8,9,4,6,85};
        System.out.println(opA.sumar(arreglo));
        System.out.println(opA.menor(arreglo));
        System.out.println(opA.mayor(arreglo));
        System.out.println(opA.promedio(arreglo));
        arreglo= opA.ordenar(arreglo);
       
        for(int i=0; i<arreglo.length; i++){
            System.out.print(arreglo[i]+" ");
        }
      
        System.out.println("\n\nOperaciones con Cadenas");
        String a ="Morlow", b="Marlowes";
        System.out.println(opC.comparadorIgualdad(a, b));
        System.out.println(opC.comparadorDiferente(a, b));
        System.out.println(opC.compararSimiTotal(a, b));
        
        
        System.out.println("\n\nOperaciones con Numeros");
        int x=5, y=2;
        System.out.println(opS.sumar(x, y));
        System.out.println(opS.resta(x, y));
        System.out.println(opS.multiplicacion(x, y));
        System.out.println(opS.division(x, y));
        
    }
    
}
