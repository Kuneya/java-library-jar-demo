/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uam.azc;

/**
 *Clase que resuelve operaciones sencillas de comparacion entre 2 cadenas de caracteres
 * @author Fernando Fabian España Lopez
 * @author Luis Javier 
 * @author Soto Arciga German Ulises
 * @version 1.0
 */
public class OperacionCadena {
    
    /**
     * Método que devuelve la cantidad de caracteres iguales entre dos cadenas
     * @param a Cadena uno
     * @param b Cadena dos
     * @return La cantidad de caracteres iguales
     */
    public int comparadorIgualdad(String a, String b){
        int cont=0;
        if(a.length()==b.length()){
           for(int i=0;i<a.length();i++){
             if(a.charAt(i)==b.charAt(i)){
                cont++;
             }
           }
        } else if(a.length()>b.length()){
            for(int i=0;i<b.length();i++){
                if(a.charAt(i)==b.charAt(i)){
                cont++;
             }
            }
            
        } else {
            for(int i=0;i<a.length();i++){
                if(a.charAt(i)==b.charAt(i)){
                cont++;
             }
            }
        }
        return cont;
    }
    
    /**
     * Método que devuelve la cantidad de caracteres diferentes entre dos cadenas
     * @param a Cadena uno
     * @param b Cadena dos
     * @return La cantidad de caracteres diferentes
     */
     public int comparadorDiferente(String a, String b){
        int cont=0;
        if(a.length()==b.length()){
           for(int i=0;i<a.length();i++){
             if(a.charAt(i)!=b.charAt(i)){
                cont++;
             }
           }
        } else if(a.length()>b.length()){
            for(int i=0;i<b.length();i++){
                if(a.charAt(i)!=b.charAt(i)){
                cont++;
             }
            }
            
        } else if (a.length()<b.length()){
            for(int i=0;i<a.length();i++){
                if(a.charAt(i)!=b.charAt(i)){
                cont++;
             }
            }
        }
        return cont;
    }
     
    /**
     * Método que devuelve la similitud total entre dos cadenas con base en la dis4654654
     * @param a Cadena uno
     * @param b Cadena dos
     * @see <a href="https://docs.informatica.com/es_es/data-integration/data-services/10-2-hotfix-2/developer-transformation-guide/transformacion-de-comparacion/estrategias-para-la-coincidencia-de-campos/distancia-de-hamming.html">Distancia de Hamming</a>
     * @return El número real de la  cantidad de similitud total
     */
    public double compararSimiTotal(String a, String b){
        int cont=0;
        double max=0.0;
        if(a.length()==b.length()){
            max=a.length();
           for(int i=0;i<a.length();i++){
             if(a.charAt(i)==b.charAt(i)){
                cont++;
             }
           }
        } else if(a.length()>b.length()){
             max=a.length();
            for(int i=0;i<b.length();i++){
                if(a.charAt(i)==b.charAt(i)){
                cont++;
             }
            }
           
            
        } else {
            max=b.length();
            for(int i=0;i<a.length();i++){
                if(a.charAt(i)==b.charAt(i)){
                cont++;
             }
            }
        }
        return cont/max;
        
    }
 
}
