/*3
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uam.azc;

/**
 *Clase para resolver operaciones sencillas
 * @author Fernando Fabian España Lopez
 * @author Luis Javier 
 * @author Soto Arciga German Ulises
 * @version 1.0
 */
public class OperacionSimple {
    /**
     * Metodo que realiza la suma de dos numeros enteros 
     * @param a sumando 1
     * @param b sumando 2
     * @return la suma de valores a y b
     */
    
    
    public int sumar(int a, int b){
        return a+b;
    } 
    
    /**
     * Metodo para restar la resta de dos numeros enteros
     * @param a el dato del minuendo de la resta
     * @param b el dato del sustraendo de la resta
     * @return la resta de a y b
     */
    
    public int resta(int a, int b){
        return a-b;
    }
    
    /**
     * Mestodo que realiza la multiplicacion  de dos numeros reales
     * @param a factor 1
     * @param b factor 2
     * @return  el valor del producto entre a y b
     */
    
    public int multiplicacion(int a, int b){
        return a*b;
    }
    
    /**
     * Mteodo que divide dos nuemros reales.
     * @param a El dato del divisor para la division
     * @param b El dato del divisor para la division
     * @see <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html">Clase Math</a>
     * @return El valor de la divición entre los números a y b
     */
     public double division(int a, int b){
        if(b==0){
            return 0;
        }else{
            double x =a*1.0/b;
            return Math.round(x*100.0)/100.0;
        }
    }
    
}
