/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.uam.azc;

/**
 * Clase que resuelve operaciones senciallas con arreglos de enteros
 * @author Fernando Fabian España Lopez
 * @author Luis Javier 
 * @author Soto Arciga German Ulises
 * @version 1.0
 */
public class OperacionArreglo {
    
    /**
     * Método que realiza la suma de los números de un arreglo de enteros
     * @param arreglo Arreglo de enteros
     * @return La suma de los enteros del arreglo
     */
    public int sumar(int arreglo[]){
        int resultado=0;
        for(int i=0; i<arreglo.length; i++){
            resultado+=arreglo[i];
        }
        return resultado;
    }
    
    /**
     * Método que devuelve el número menor de los números enteros de un arreglo
     * @param arreglo Arreglo de enteros
     * @return El número menor de los enteros
     */
    public int menor(int arreglo[]){
        int menor=arreglo[0];
        for(int i=0; i<arreglo.length; i++){
            if(menor>arreglo[i]){
                menor=arreglo[i];
            }
        }
        return menor;
    }
    
    /**
     * Método que devuelve el número mayor de los números enteros de un arreglo
     * @param arreglo Arreglo de enteros
     * @return El número mayor de los enteros
     */
    public int mayor(int arreglo[]){
        int mayor=arreglo[0];
        for(int i=0; i<arreglo.length; i++){
             if(mayor<arreglo[i]){
                mayor=arreglo[i];
            }
        }
        return mayor;
    }
    
    /**
     * Método que devuelve el promedio de los números enteros de un arreglo
     * @param arreglo Arreglo de enteros
     * @return El número real del promedio los enteros
     * @see <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html">Clase Math</a>
     */
    public double promedio(int arreglo[]){
        double promedio=0;
        for(int i=0; i<arreglo.length; i++){
            if(i<arreglo.length){
                promedio+=arreglo[i];
            }
        }
        promedio= promedio/arreglo.length;
        return  Math.round(promedio*100.0)/100.0;
    }
    
    /**
     * Método que devuelve un arreglo ordenado de menor a mayor a partir de un arreglo de enteros, utilizando el metodo Insertion Sort
     * @param t Arreglo de enteros
     * @return El arreglo ordenado de menor a mayor
     * @see <a href="http://lwh.free.fr/pages/algo/tri/tri_insertion_es.html">Ordenamiento por inserción</a>
     */
    public int[] ordenar(int t[]){
        int i, j;
        int actual;

        for (i = 1; i < t.length; i++) {
            actual = t[i];
            for (j = i; j > 0 && t[j - 1] > actual; j--) {
                t[j] = t[j - 1];
            }
            t[j] = actual;
        }
        return t;
    }
}
